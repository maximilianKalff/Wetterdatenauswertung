// Upload file
const myForm = document.getElementById("myForm");
    const csvFile = document.getElementById("csvFile");

    function csvToArray(str, delimiter = ",") {

      // slice from start of text to the first \n index
      // use split to create an array from string by delimiter
      const headers = str.slice(0, str.indexOf("\n")).split(delimiter);

      // slice from \n index + 1 to the end of the text
      // use split to create an array of each csv value row
      const rows = str.slice(str.indexOf("\n") + 1).split("\n");

      // Map the rows
      // split values from each row into an array
      // use headers.reduce to create an object
      // object properties derived from headers:values
      // the object passed as an element of the array
      const arr = rows.map(function (row) {
        const values = row.split(delimiter);
        const el = headers.reduce(function (object, header, index) {
          object[header] = values[index];
          return object;
        }, {});
        return el;
      });

      // return the array
      return arr;
    }

    myForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const input = csvFile.files[0];
      const reader = new FileReader();

      reader.onload = function (e) {
        const text = e.target.result;
        const data = csvToArray(text);
        document.write(JSON.stringify(data));
      };
      
      reader.readAsText(input);
    });



// === Temperature-Height ===
let xdata = [23, 20,17,12,6,-3,-10,-20,-40,-48,-52,-49, -36, -20, -1, 12, 23];
let labels = [0, 1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,14000,15000,16000]

labels = labels.reverse();
xdata = xdata.reverse();

  const data = {
    labels: labels,  
    datasets: [{
      data: xdata,
      backgroundColor: '#58508d',
      borderColor: '#58508d',
      
    }]
  };

  const config = {
    type: 'line',
    data: data,
    
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins:{
        legend: {
          display: false
        },
      },
      
      scales: {        
        x: {
          position: {y:0},
          ticks: {
            autoSkip: false,
            maxRotation: 90,
            minRotation: 90
          }
        },
        y: {
          position: 'right',
          ticks: {
            autoSkip: false,
            maxRotation: 90,
            minRotation: 90
          }
        }
      },
    }
  };
  
  const myChart = new Chart(
    document.getElementById('temperature'),
    config,
    
  );

const app = Vue.createApp({
})

app.mount('#app')